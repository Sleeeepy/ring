<?php
// Heading
$_['heading_title']       = 'Hello World';
 
// Text
$_['text_module']         = 'Modules';
$_['text_edit']           = 'Edit Hello World Module';
$_['text_success']        = 'Success: You have modified module Hello World!';
 
// Entry
$_['entry_code']          = 'Hello World Code:';
$_['entry_status']        = 'Status:';
 
// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module Hello World!';
$_['error_code']          = 'Code Required';