<?php
// Heading 
$_['heading_title']  = 'Hello World Title';